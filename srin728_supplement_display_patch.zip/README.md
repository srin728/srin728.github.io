# Supplement display patch

This patch changes presentation only; `data/supplemental.json` is not changed.

- Coauthor talks: same simple reversed numbered list as homepage Talks.
- Updates: compact bullet list `text (YYYY-MM-DD)`, inspired by https://yasu0207.github.io/.

Apply:
```bash
git pull --rebase origin main
python /path/to/srin728_supplement_display_patch/apply_supplement_display.py .
git status --short
git diff
git add -A
git commit -m "Align supplement presentation"
git push
```
