# CI fix

`tests/` was removed, but the workflow still called:

```bash
python -m unittest discover -s tests
```

This patch removes that stale dependency and replaces it with generator syntax checks plus deterministic `--check` validation.
