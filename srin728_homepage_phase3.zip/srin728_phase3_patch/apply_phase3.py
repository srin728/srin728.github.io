#!/usr/bin/env python3
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

LEGACY_PATHS = (
    "PHASE2_README.md",
    "apply_phase2.py",
    "apply_phase2_continuation.py",
    "build_homepage.py",
    "homepage.json",
    "patch",
)

CACHE_DIRS = (
    "scripts/__pycache__",
    "tests/__pycache__",
)


def run(cmd, cwd: Path):
    print("+", " ".join(str(x) for x in cmd))
    subprocess.run(cmd, cwd=cwd, check=True)


def remove_path(path: Path):
    if path.is_dir():
        shutil.rmtree(path)
        print(f"removed {path}")
    elif path.exists():
        path.unlink()
        print(f"removed {path}")


def clear_python_caches(repo: Path):
    for rel in CACHE_DIRS:
        remove_path(repo / rel)
    for pyc in repo.rglob("*.pyc"):
        try:
            pyc.unlink()
        except OSError:
            pass


def main() -> int:
    if len(sys.argv) > 2:
        print("usage: python apply_phase3.py [repository-root]", file=sys.stderr)
        return 2

    package_root = Path(__file__).resolve().parent
    payload = package_root / "payload"
    repo = Path(sys.argv[1] if len(sys.argv) == 2 else ".").resolve()

    required = [
        repo / "lang" / "en.json",
        repo / "lang" / "ja.json",
        repo / "data" / "homepage.json",
        repo / "articles",
        repo / "scripts" / "build_blog.py",
        repo / "style.css",
        repo / "blog.css",
    ]
    missing = [path for path in required if not path.exists()]
    if missing:
        print("This does not look like the current srin728.github.io repository.", file=sys.stderr)
        for path in missing:
            print(f"  missing: {path}", file=sys.stderr)
        return 1

    for rel in LEGACY_PATHS:
        remove_path(repo / rel)
    clear_python_caches(repo)

    for src in payload.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(payload)
        dst = repo / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        print(f"updated {rel}")

    run([sys.executable, "scripts/build_homepage.py"], repo)
    run([sys.executable, "scripts/build_blog.py"], repo)
    run([sys.executable, "scripts/build_supplement.py"], repo)
    run([sys.executable, "scripts/build_site_meta.py"], repo)
    run([sys.executable, "-m", "unittest", "discover", "-s", "tests"], repo)

    # Tests create __pycache__ directories. Remove them once more so the
    # already-tracked Phase 2 cache files are staged as deletions by git add -A.
    clear_python_caches(repo)

    print()
    print("Phase 3 applied successfully.")
    print("Review: git status --short && git diff")
    print("Commit with: git add -A && git commit -m \"Phase 3 homepage maintenance\"")
    print("Then push. GitHub Actions will rebuild generated pages automatically.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
