# Phase 3 patch

## What this changes

- Footer update date is automatic.
  - It is derived from the latest Git commit touching meaningful site source files.
  - Generated-page commits do not move the displayed date by themselves.
- Removes clear Phase 1/2 migration leftovers and duplicate files.
- Adds `supplement.html` for:
  - 共著者による発表
  - 近況報告
- Adds a lightweight `#f8c112` / `#f6ae54` design in `supplement.css`.
- Adds a `Supplement / 補足情報` link under `Misc`.
- Adds Phase 3 SEO:
  - Schema.org structured data
  - Open Graph metadata
  - `sitemap.xml`
  - `robots.txt`
- Adds `.gitignore` so Python cache files are not committed again.
- Updates the automatic GitHub Actions build.

## Files removed by the installer

Only clearly obsolete migration/build duplicates are removed:

- `PHASE2_README.md`
- `apply_phase2.py`
- `apply_phase2_continuation.py`
- root `build_homepage.py`
- root `homepage.json`
- `patch/`
- tracked Python cache directories

`articles/*.md`, the parameterized-complexity database builder, and its tests are preserved.

## Apply

Extract this ZIP somewhere outside the repository if possible, then run:

```bash
python apply_phase3.py /path/to/srin728.github.io
```

If the installer itself is placed in the repository root:

```bash
python apply_phase3.py .
```

After it succeeds:

```bash
git status --short
git diff
git add -A
git commit -m "Phase 3 homepage maintenance"
git push
```

The `git add -A` is important because it records the cleanup deletions.

## Editing the new supplementary page

Edit:

```text
data/supplemental.json
```

Then either run locally:

```bash
python scripts/build_supplement.py
```

or simply commit/push the JSON change. GitHub Actions will build the HTML.

See the repository `README.md` installed by this patch for the data schema.
